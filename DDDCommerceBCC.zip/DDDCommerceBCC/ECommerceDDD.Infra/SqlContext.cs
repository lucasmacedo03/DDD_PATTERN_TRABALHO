﻿using ECommerceDDD.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace ECommerceDDD.Infra
{
    public class SqlContext : DbContext
    {


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=UniversidadeDb");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //modelBuilder.Entity<Matricula>().HasKey(m => new { m.AlunoId, m.DisciplinaId });
            //modelBuilder.Entity<Aluno>()
            //    .HasMany(e => e.Disciplinas)
            //    .WithMany(e => e.Alunos)
            //    .UsingEntity<Matricula>();


            //modelBuilder.Entity<User>().UseTpcMappingStrategy();
            //modelBuilder.Entity<Aluno>().ToTable("Aluno");
            //modelBuilder.Entity<Pesquisador>().ToTable("Pesquisador");
            //https://learn.microsoft.com/pt-br/ef/core/modeling/inheritance
        }

        public DbSet<Pedido> Pedidos { get; set; }
        //public DbSet<Disciplina> Disciplinas { get; set; }
        //public DbSet<Matricula> Matriculas { get; set; }
        //public DbSet<User> Users { get; set; }
        //public DbSet<Pesquisador> Pesquisadores { get; set; }
        //public DbSet<Projeto> Projetos { get; set; }
    }
}
