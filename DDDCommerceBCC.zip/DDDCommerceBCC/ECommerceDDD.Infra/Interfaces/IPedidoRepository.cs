﻿using ECommerceDDD.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECommerceDDD.Infra.Interfaces
{
    public interface IPedidoRepository
    {
        Pedido GetPedidoById(int id);
        bool AddPedido(Pedido pedido);
        List<Pedido> GetAll();
        Pedido UpdatePedido(int id, Pedido pedido);
        bool  DeletePedido(int id);
    }
}
